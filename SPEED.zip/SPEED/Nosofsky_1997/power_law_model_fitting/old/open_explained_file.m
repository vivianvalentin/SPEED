% result = dlmread('explained.dat','\t')
clear
clc
% import= dlmread('explained.dat')
% import{:}

fid= fopen('explained.dat')
x= fgetl(fid)
x2= fgetl(fid)
x3= fgetl(fid)
x4= fgetl(fid)
x5= fgetl(fid)
x6= fgetl(fid)
x7= fgetl(fid)
x8= fgetl(fid)
