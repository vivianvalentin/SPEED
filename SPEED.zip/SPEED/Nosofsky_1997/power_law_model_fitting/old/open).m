% result = dlmread('explained.dat','\t')
clear
clc
[import]= importdata('explained.dat')
% import= dlmread('explained.dat')
% import{:}